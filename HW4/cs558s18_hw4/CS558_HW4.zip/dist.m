function class = assign(train_hist,test_hist)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%   coast,forest,insidecity
[bins,ch] = size(test_hist);
for i = 1:bins
    for j = 1:ch
        
    end
end
end

