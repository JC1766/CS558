%Jerry Chen
%CS558 HW4
%I pledge my honor that I have abided by the Stevens Honor System
D = 'ImClass';
classify(8,D);
classify(16,D);
D = 'sky';
pix_classify(10,D)